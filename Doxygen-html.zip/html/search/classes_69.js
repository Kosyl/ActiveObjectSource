var searchData=
[
  ['identity',['identity',['../struct_active_object_1_1_logger_1_1identity.html',1,'ActiveObject::Logger']]]
];
