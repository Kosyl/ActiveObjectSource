var searchData=
[
  ['type',['type',['../struct_active_object_1_1_logger_1_1identity.html#a057ee058c85bdaaa840a548ea74b7e1d',1,'ActiveObject::Logger::identity']]]
];
