var searchData=
[
  ['cancelled',['CANCELLED',['../namespace_active_object.html#a1703dc5eff7e0a63d4fdd9a8086ada34a0713b61a59d5a153ca1ee9b1ff62574b',1,'ActiveObject']]]
];
