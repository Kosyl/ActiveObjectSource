var searchData=
[
  ['lock',['lock',['../class_active_object_1_1_logger.html#aa27de6c151e1ddede72ba1201783d1c1',1,'ActiveObject::Logger']]],
  ['logger',['Logger',['../class_active_object_1_1_logger.html#ae45f9c9651b7d904471552c1e9d04a0f',1,'ActiveObject::Logger::Logger()'],['../class_active_object_1_1_logger.html#ac1106fbe93b2cabd8e54f98fe04d4310',1,'ActiveObject::Logger::Logger(string s, short color=15)']]]
];
