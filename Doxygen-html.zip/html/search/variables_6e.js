var searchData=
[
  ['next_5f',['next_',['../class_active_object_1_1_logger.html#af33ed289484cd999e4a15b055b7658eb',1,'ActiveObject::Logger']]],
  ['notifyobservers_5f',['notifyObservers_',['../class_active_object_1_1_future_content.html#a681be0324c8ffd10e60a186cff5f9d1a',1,'ActiveObject::FutureContent']]]
];
