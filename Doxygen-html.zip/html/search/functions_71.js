var searchData=
[
  ['queueproxy',['QueueProxy',['../class_queue_proxy.html#ac7b98a9bc0756cb7b976ab6350943b5d',1,'QueueProxy']]],
  ['queueservant',['QueueServant',['../class_queue_servant.html#afb98fd5978303307b6eb5c6674c4d4d2',1,'QueueServant']]]
];
