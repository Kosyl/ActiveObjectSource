var searchData=
[
  ['logger',['Logger',['../class_active_object_1_1_logger.html',1,'ActiveObject']]]
];
